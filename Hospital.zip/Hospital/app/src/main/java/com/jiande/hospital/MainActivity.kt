package com.jiande.hospital

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Register_Bottom.setOnClickListener{
            val username = Register_Username.text.toString()
            val mail = Register_Email.text.toString()
            val password = Register_Password.text.toString()
            Log.d("MainActivity","Username is : $username")
            Log.d("MainActivity","Email is : $mail")
            Log.d("MainActivity","Password :  $password")
            //FireBase Authentication to create a user with email and password

        }

        Register_already.setOnClickListener{
            Log.d("MainActivity","Try to Go Login Activity")
            //launch login activity
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }
    }
}