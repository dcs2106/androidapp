package com.jiande.hospital

import android.os.Bundle
import android.os.PersistableBundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.activity_main.*

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        Login_BackReg.setOnClickListener(){
            Log.d("MainActivity","LoginActivity Try to Go Main Activity")
            finish()
        }

        Login_Button.setOnClickListener{
            //val username = Register_Username.text.toString()
            val mail = Login_Email.text.toString()
            val password = Login_Password.text.toString()
            //Log.d("MainActivity","Username is : $username")
            Log.d("MainActivity","Email is : $mail")
            Log.d("MainActivity","Password :  $password")
            //FireBase Authentication to create a user with email and password

        }
    }
}